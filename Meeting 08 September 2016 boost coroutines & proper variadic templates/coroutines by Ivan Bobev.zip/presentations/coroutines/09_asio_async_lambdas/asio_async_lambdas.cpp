#include <iostream>
#include <chrono>
#include <boost/asio.hpp>

using namespace std;
using namespace boost::asio;

io_service ioService;
ip::tcp::resolver resolver(ioService);

vector<ip::tcp::socket> sockets;
vector<array<char, 8192>> data;
vector<size_t> fileSizes;

void download(const string& host, const string& file, size_t index)
{
  clog << "Downloading " << host << file << " ..." << endl;

  ip::tcp::resolver::query query(host, "80");

  resolver.async_resolve(query, [index, &file](const auto& ec, auto it)
  {
    if (ec) return;

    sockets[index].async_connect(*it, [index, &file](const auto& ec)
    {
      if (ec) return;

      ostringstream req;
      req << "GET " << file << " HTTP/1.0\r\n\r\n";
      write(sockets[index], buffer(req.str()));

      function<void (const boost::system::error_code&, size_t)> readCallback;

      readCallback = [index, &readCallback](const auto& ec, size_t bytesRead)
      {
        if (ec) return;

        fileSizes[index] += bytesRead;

        sockets[index].async_read_some(buffer(data[index]), readCallback);
      };

      sockets[index].async_read_some(buffer(data[index]), readCallback);
    });
  });
}

int main()
{
  auto timeBegin = chrono::high_resolution_clock::now();

  vector<pair<string, string>> resources =
  {
    {"www.w3.org", "/TR/html401/html40.txt"},
    {"www.w3.org", "/TR/2002/REC-xhtml1-20020801/xhtml1.pdf"},
    {"www.w3.org", "/TR/REC-html32.html"},
    {"www.w3.org", "/TR/2000/REC-DOM-Level-2-Core-20001113/DOM2-Core.txt"},
  };

  for (size_t i = 0; i < resources.size(); ++i)
  {
    sockets.emplace_back(ioService);
    fileSizes.emplace_back(0);
  }

  data.resize(resources.size());

  size_t i = 0;
  for (const auto& res : resources)
  {
    download(res.first, res.second, i++);
  }

  ioService.run();

  i = 0;
  for (auto size : fileSizes)
  {
    cout << resources[i++].second << " size: " << size << endl;
  }

  auto timeEnd = chrono::high_resolution_clock::now();

  clog << "Time: " << chrono::duration_cast<chrono::milliseconds>(
            timeEnd - timeBegin).count() << endl;

  return 0;
}
