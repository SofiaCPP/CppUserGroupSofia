#include <iostream>
#include <boost/context/all.hpp>

using namespace std;
using namespace boost::context;

int main()
{
  execution_context<int> source([](execution_context<int> sink, int)
  {
    int first = 0;
    int second = 1;
    while (true)
    {
      auto result = sink(first);
      sink = move(get<0>(result));
      auto next = first + second;
      first = second;
      second = next;
    }
    return sink;
  });

  for (int i = 0; i < 10; ++i)
  {
    auto result = source(i);
    source = move(get<0>(result));
    cout << i << "\t->\t" << get<1>(result) << endl;
  }

  return 0;
}
