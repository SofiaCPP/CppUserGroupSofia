#include <iostream>
#include <boost/coroutine/asymmetric_coroutine.hpp>

using namespace std;
using namespace boost::coroutines;

struct FinalEOL
{
  ~FinalEOL()
  {
    cout << endl;
  }
};

int main()
{
  const int num = 5, width = 15;

  asymmetric_coroutine<string>::push_type writer(
    [&](asymmetric_coroutine<string>::pull_type& in)
  {
    // finish the last line when we leave by whatever means
    FinalEOL eol;

    // pull values from upstream, lay them out 'num' to a line
    for (;;)
    {
      for (int i = 0; i < num; ++i)
      {
          // when we exhaust the input, stop
          if (!in)
          {
            return;
          }

          cout << setw(width) << in.get();

          // now that we've handled this item, advance to next
          in();
      }

      // after 'num' items, line break
      cout << endl;
    }
  });

  vector<string> words
  {
    "peas", "porridge", "hot", "peas",
    "porridge", "cold", "peas", "porridge",
    "in", "the", "pot", "nine",
    "days", "old"
  };

  copy(begin(words), end(words), begin(writer));
}
