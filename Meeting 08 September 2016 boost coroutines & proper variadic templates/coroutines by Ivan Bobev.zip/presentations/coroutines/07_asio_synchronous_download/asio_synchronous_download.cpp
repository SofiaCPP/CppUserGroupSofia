#include <iostream>
#include <chrono>
#include <boost/asio.hpp>

using namespace std;
using namespace boost::asio;

io_service ioService;

void download(const string& host, const string& file)
{
  clog << "Downloading " << host << file << " ..." << endl;

  ip::tcp::socket socket(ioService);
  ip::tcp::resolver resolver(ioService);

  ip::tcp::resolver::query query(host, "80");
  auto endpointIter = resolver.resolve(query);
  socket.connect(*endpointIter);

  ostringstream req;
  req << "GET " << file << " HTTP/1.0\r\n\r\n";
  write(socket, buffer(req.str()));

  size_t fileSize = 0;

  while (true)
  {
    char data[8192];
    boost::system::error_code error;
    size_t bytesRead = socket.read_some(buffer(data), error);
    if(0 == bytesRead) break;
    fileSize += bytesRead;
  }

  socket.shutdown(ip::tcp::socket::shutdown_both);
  socket.close();

  cout << "File size: " << fileSize << endl;
}

int main()
{
  auto timeBegin = chrono::high_resolution_clock::now();

  vector<pair<string, string>> resources =
  {
    {"www.w3.org", "/TR/html401/html40.txt"},
    {"www.w3.org", "/TR/2002/REC-xhtml1-20020801/xhtml1.pdf"},
    {"www.w3.org", "/TR/REC-html32.html"},
    {"www.w3.org", "/TR/2000/REC-DOM-Level-2-Core-20001113/DOM2-Core.txt"},
  };

  for (const auto& res : resources)
  {
    download(res.first, res.second);
  }

  auto timeEnd = chrono::high_resolution_clock::now();

  cout << "Time: " << chrono::duration_cast<chrono::milliseconds>(
            timeEnd - timeBegin).count() << " milliseconds." << endl;

  return 0;
}
