#include <iostream>
#include <boost/coroutine/asymmetric_coroutine.hpp>

using namespace std;
using namespace boost::coroutines;

using Permutation = std::vector<unsigned>;

void printPerm(const Permutation& perm)
{
  for (size_t i = 0; i < perm.size(); ++i)
  {
    cout << perm[i] << " ";
  }
  cout << endl;
}

int main()
{
  unsigned n;
  cout << "n = ";
  cin >> n;

  asymmetric_coroutine<Permutation>::pull_type genPerms([n](auto& sink)
  {
    Permutation perm(n);
    vector<bool> used(n, false);

    function<void (unsigned)> genPermRec = [&, n](unsigned index)
    {
      if (index == n)
      {
        sink(perm);
      }

      for (size_t i = 0; i < n; ++i)
      {
        if (!used[i])
        {
          used[i] = true;
          perm[index] = i;
          genPermRec(index + 1);
          used[i] = false;
        }
      }
    };

    genPermRec(0);
  });

  for (const auto& perm : genPerms)
  {
    printPerm(perm);
  }

  return 0;
}
