#include <iostream>
#include <boost/coroutine/asymmetric_coroutine.hpp>

using namespace std;
using namespace boost::coroutines;

int main()
{
  asymmetric_coroutine<int>::pull_type source(
        [](asymmetric_coroutine<int>::push_type& sink)
  {
    int first = 1, second = 1;
    sink(first);
    sink(second);
    for(int i = 0;i < 8; ++i)
    {
      int third = first + second;
      first = second;
      second = third;
      sink(third);
    }
  });

  for (auto i : source)
  {
    cout << i <<  " ";
  }
  cout << endl;

  return 0;
}
