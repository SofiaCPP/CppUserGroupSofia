#include <iostream>
#include <fstream>
#include <sstream>

#include <boost/coroutine/symmetric_coroutine.hpp>

using namespace std;
using namespace boost::coroutines;

int main()
{
  string inputFileName, outputFileName;
  cout << "Input file name: ";
  cin >> inputFileName;
  cout << "Output file name: ";
  cin >> outputFileName;

  ifstream finp(inputFileName);
  ofstream fout(outputFileName);

  symmetric_coroutine<void>::call_type* reader;
  symmetric_coroutine<string>::call_type* lineNumberAppender;
  symmetric_coroutine<string>::call_type* writer;

  symmetric_coroutine<void>::call_type producer(
        [&finp, &lineNumberAppender](auto& yield)
  {
    do
    {
      string line;
      getline(finp, line);
      if (line.empty()) break;
      yield(*lineNumberAppender, line);
    }
    while (true);
  });

  symmetric_coroutine<string>::call_type mapper(
        [&writer](auto& yield)
  {
    size_t lineNumber = 0;
    while (true)
    {
      ostringstream oss;
      const auto& line = yield.get();
      oss << ++lineNumber << "\t" << line;
      yield(*writer, oss.str());
    }
  });

  symmetric_coroutine<string>::call_type consumer(
        [&fout, &reader](auto& yield)
  {
    while (true)
    {
      const auto& line = yield.get();
      fout << line << endl;
      yield(*reader);
    }
  });

  reader = &producer;
  lineNumberAppender = &mapper;
  writer = &consumer;

  producer();

  return 0;
}
